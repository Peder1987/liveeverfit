'use strict';

define(['app'], function(app) {

    app.register.controller('upgradeCtrl', ['$scope',
    	function($scope) {
    }]);
    
});