'use strict';

define(['app'], function(app) {

    app.register.controller('termsCtrl', ['$scope',
    	function($scope) {
    }]);
    
});