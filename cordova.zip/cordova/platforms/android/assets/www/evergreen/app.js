'use strict';

define(['app'], function(app) {

    app.register.controller('evergreenCtrl', ['$scope',
    	function($scope) {
    }]);
    
});